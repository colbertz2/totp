// Header file for otp.c

int get_otp();

char* _otp_read_key();
char* _otp_get_time();
