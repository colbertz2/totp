// Header file for otp.c

int get_otp();

unsigned char* _otp_read_key();
unsigned char* _otp_get_time();
