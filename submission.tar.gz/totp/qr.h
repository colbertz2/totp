// Header file for qr.c

int qr_generate();
