// Tests for qr.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "qr.h"

int main() {

    qr_generate();

    return 0;
}